import java.lang.Math;
import java.util.HashMap;

public class Main {

    public static void main(String[] args) {

        /*Wpisywanie formuł
         "!"-negacja
         "*"-koniunkcja
         "+"-alternatywa
        ">"-implikacja
        "="-rownowaznosc
        ()-nawiasy
         */
        boolean [][] lVars = lVarsGen(3);
        String [] zmienneNazwy = {"p", "q", "r"};
        String FORMULA = "( p > q ) > ( ( p * r ) > q ) ";
        foo(lVars, zmienneNazwy, FORMULA);
    }
    public static boolean [][] lVarsGen(int liczba) {
        int liczbaDop = (int) Math.pow(2, liczba);
        boolean [][] array = new boolean[liczbaDop][liczba];

        for(int i = liczba-1; i >= 0; --i) {
            int tmp = ((int) Math.pow(2, liczba-i));
            for(int j = 0; j < liczbaDop; ++j) {
                if((j % tmp) < (tmp/2))
                    array[j][i] = false;
                else
                    array[j][i] = true;
            }
        }
        return array;
    }

    public static void foo (boolean [][] lVars, String [] zmienneNazwy, String F) {
        for(String i : zmienneNazwy)
            System.out.print(" "+i+" |");
        System.out.println(" "+F);
        for(int i = 0; i < lVars.length; ++i) {
            HashMap<String, Integer> m = new HashMap<>();
            for(int j = 0; j < lVars[0].length; ++j) {
                if(lVars[i][j]) {
                    System.out.print(" 1 |");
                    m.put(zmienneNazwy[j], 1);
                }
                else {
                    System.out.print(" 0 |");
                    m.put(zmienneNazwy[j], 0);
                }
            }
            for(int j = 0; j < F.length()/2; ++j)
                System.out.print(" ");
            
            if(plTrue(F, m))
                System.out.println(1);
            else
                System.out.println(0);
        }
    }
    public static Boolean plTrue(String F, HashMap<String, Integer> m) {
        if(F.indexOf("(") != -1) {
            while (F.indexOf("(") != -1) {
                Integer indexOfnawiasZam = F.indexOf(")");
                Integer indexOfnawiasOpen = null;
                for (Integer i = indexOfnawiasZam; i >= 0 && indexOfnawiasOpen == null; --i)
                    if (("" + F.charAt(i)).equals("(")) {
                        indexOfnawiasOpen = i;
                    }


                String fBez = F.substring(indexOfnawiasOpen+1, indexOfnawiasZam);
                if(plTrueBezNawiasow(fBez, m))
                    F = F.substring(0, indexOfnawiasOpen)+"1"+F.substring(indexOfnawiasZam+1);
                else
                    F = F.substring(0, indexOfnawiasOpen)+"0"+F.substring(indexOfnawiasZam+1);
            }
            return plTrueBezNawiasow(F, m);
        } else {
            return plTrueBezNawiasow(F, m);
        }
    }

    
    public static Boolean plTrueBezNawiasow(String F, HashMap<String, Integer> m) {
        String [] binOp = {"*", "+", ">", "="};
        F = F.replace(" ", "");
        for(String i : m.keySet()) {
            F = F.replace(i, m.get(i).toString());
        }
        while(F.indexOf("!") != -1) {
            Integer index = F.indexOf("!");
            String value = ""+F.charAt(index+1);
            if(value.equals("1"))


                F = F.substring(0,index)+"0"+F.substring(index+2);
            else
                F = F.substring(0,index)+"1"+F.substring(index+2);
        }


        for(String op : binOp) {
            while (F.indexOf(op) != -1) {
                Integer index = F.indexOf(op);
                String firstA = "" + F.charAt(index-1);
                String secondA = "" + F.charAt(index+1);
                if(op.equals("*")) {
                    if(firstA.equals("1") && secondA.equals("1"))
                        F = F.substring(0, index-1)+"1"+F.substring(index+2);
                    else
                        F = F.substring(0, index-1)+"0"+F.substring(index+2);;
                }
                if(op.equals("+")) {
                    if(firstA.equals("0") && secondA.equals("0"))
                        F = F.substring(0, index-1)+"0"+F.substring(index+2);
                    else
                        F = F.substring(0, index-1)+"1"+F.substring(index+2);;
                }
                if(op.equals(">")) {
                    if(firstA.equals("1") && secondA.equals("0"))
                        F = F.substring(0, index-1)+"0"+F.substring(index+2);
                    else
                        F = F.substring(0, index-1)+"1"+F.substring(index+2);;
                }
                if(op.equals("=")) {
                    if(firstA.equals(secondA))
                        F = F.substring(0, index-1)+"1"+F.substring(index+2);
                    else
                        F = F.substring(0, index-1)+"0"+F.substring(index+2);;
                }
            }
        }
        if(F.equals("1"))
            return true;
        else
            return false;
    }


}
